import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { WebsimSocket } from "@websim/websim-socket";

const room = new WebsimSocket();

// ---------------- Voxel world types ----------------
const BLOCKS = [
  { id: 0, name: "Grass", colors: { top: [0x46a04a, 0x3c8940], side: [0x6b4b2a, 0x5a3d21], bottom: [0x5a3d21, 0x54381e] } },
  { id: 1, name: "Dirt", colors: { top: [0x7a5231, 0x6b4627], side: [0x7a5231, 0x6b4627], bottom: [0x6b4626, 0x63401f] } },
  { id: 2, name: "Stone", colors: { top: [0x8a8a8a, 0x7c7c7c], side: [0x8a8a8a, 0x7c7c7c], bottom: [0x7d7d7d, 0x737373] } },
  { id: 3, name: "Wood", colors: { top: [0x9c7b4a, 0x8a6b3e], side: [0x6e4a24, 0x613f1d], bottom: [0x8a6b3e, 0x7c5f35] } },
  { id: 4, name: "Planks", colors: { top: [0xa8824e, 0x9c7747], side: [0xa8824e, 0x9c7747], bottom: [0x9c7747, 0x906f42] } },
  { id: 5, name: "Leaves", colors: { top: [0x3e7c37, 0x356b30], side: [0x3e7c37, 0x356b30], bottom: [0x356b30, 0x2e5e29] } },
  { id: 6, name: "Sand", colors: { top: [0xdcc5a0, 0xd4c395], side: [0xdcc5a0, 0xd4c395], bottom: [0xd2bd90, 0xc9b487] } },
  { id: 7, name: "Glass", colors: { top: [0xd9f2ff, 0xcdecff], side: [0xd9f2ff, 0xcdecff], bottom: [0xcdedff, 0xc2e5f8] }, transparent: true },
  { id: 8, name: "Brick", colors: { top: [0x9a4a3a, 0x8a4130], side: [0x9a4a3a, 0x8a4130], bottom: [0x8a4130, 0x7d3a2b] } },
];

const GRASS_ID = 0, DIRT_ID = 1, STONE_ID = 2;

// ---------------- RNG / value noise ----------------
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makeNoise(seed) {
  const rnd = mulberry32(seed);
  const perm = new Uint32Array(512);
  const p = new Uint8Array(256);
  for (let i = 0; i < 256; i++) p[i] = i;
  for (let i = 255; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [p[i], p[j]] = [p[j], p[i]]; }
  for (let i = 0; i < 512; i++) perm[i] = p[i & 255];
  function fade(t) { return t * t * t * (t * (t * 6 - 15) + 10); }
  function grad(h, x, y) { const hs = h & 7; const u = h < 4 ? x : y; const v = h < 4 ? y : x; return ((hs & 1) ? -u : u) + ((hs & 2) ? -2 * v : 2 * v); }
  return function (x, y) {
    const X = Math.floor(x) & 255, Y = Math.floor(y) & 255;
    x -= Math.floor(x); y -= Math.floor(y);
    const u = fade(x), v = fade(y);
    const A = perm[X] + Y, B = perm[X + 1] + Y;
    return grad(perm[B + 1], x - 1, y - 1) * u * v
      + grad(perm[B], x - 1, y) * u * (1 - v)
      + grad(perm[A + 1], x, y - 1) * (1 - u) * v
      + grad(perm[A], x, y) * (1 - u) * (1 - v);
  };
}

// ---------------- Texture builder ----------------
function squareTexture(baseRgb, rnd) {
  const size = 16;
  const c = document.createElement("canvas");
  c.width = size; c.height = size;
  const g = c.getContext("2d");
  const [r, gg, b] = [
    (baseRgb >> 16) & 255, (baseRgb >> 8) & 255, baseRgb & 255,
  ];
  g.fillStyle = `rgb(${r},${gg},${b})`;
  g.fillRect(0, 0, size, size);
  const img = g.getImageData(0, 0, size, size);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (rnd() - 0.5) * 26;
    d[i] = Math.max(0, Math.min(255, d[i] + n));
    d[i + 1] = Math.max(0, Math.min(255, d[i + 1] + n));
    d[i + 2] = Math.max(0, Math.min(255, d[i + 2] + n));
  }
  g.putImageData(img, 0, 0);
  const tex = new THREE.CanvasTexture(c);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function rowTexture(rgb, n) {
  const c = document.createElement("canvas");
  c.width = 16; c.height = 48;
  const g = c.getContext("2d");
  const rnd = mulberry32(n);
  // rows: top(0-16), side(16-32), bottom(32-48)
  const top = squareTexture(rgb.top[0], rnd);
  const side = squareTexture(rgb.side[0], rnd);
  const bottom = squareTexture(rgb.bottom[0], rnd);
  g.drawImage(top.image, 0, 0);
  g.drawImage(side.image, 0, 16);
  g.drawImage(bottom.image, 0, 32);
  // add hairline seam between rows to read like minecraft tiles
  g.fillStyle = "rgba(0,0,0,0.25)";
  g.fillRect(0, 15, 16, 1);
  g.fillRect(0, 31, 16, 1);
  const tex = new THREE.CanvasTexture(c);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.flipY = true;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// ---------------- Setup ----------------
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);
scene.fog = new THREE.Fog(0x87ceeb, 40, 120);

const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.1, 200);
const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById("game"), antialias: true });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));

// lights
scene.add(new THREE.HemisphereLight(0xffffff, 0x6b6b6b, 0.9));
const sun = new THREE.DirectionalLight(0xffffff, 1.0);
sun.position.set(50, 80, 30);
scene.add(sun);
scene.add(new THREE.AmbientLight(0xffffff, 0.25));

// ---------------- World data ----------------
const world = new Map(); // key -> block id
const key = (x, y, z) => `${x},${y},${z}`;

// Persistent saves: only the player's edits (adds/removes on top of the
// generated terrain). Stored as an object mapping "x,y,z" -> block id, or
// null to mean "remove the natural block here".
const SAVE_KEY = "minicraft-world-v1";
const WORLD_COL = "minicraft_world";
const WORLD_ID = "shared";
let edits = {};

function saveEdits() {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(edits));
  } catch (e) { /* storage full or unavailable; play on without saving */ }
  // also push to the cloud so the same world shows on any device
  room.collection(WORLD_COL).upsert({ id: WORLD_ID, edits }).catch(() => {});
}

function loadEdits() {
  try {
    edits = JSON.parse(localStorage.getItem(SAVE_KEY) || "{}") || {};
  } catch (e) {
    edits = {};
  }
}

// Pull the cloud world (newest on any device) over the local one.
async function loadCloudEdits() {
  try {
    const list = await room.collection(WORLD_COL).getList();
    const rec = (list || []).find((r) => r.id === WORLD_ID);
    if (rec && rec.edits && typeof rec.edits === "object") {
      edits = rec.edits;
      try { localStorage.setItem(SAVE_KEY, JSON.stringify(edits)); } catch (e) {}
    }
  } catch (e) { /* offline or unavailable; keep local */
  }
}

// Apply saved edits on top of the freshly generated terrain.
function applyEdits() {
  for (const k in edits) {
    const v = edits[k];
    if (v === null || v === undefined) world.delete(k);
    else world.set(k, v);
  }
}

const particles = [];

// Build the grass block texture from the uploaded grass-block image:
// green top face, grass-on-dirt side, dirt bottom.
function buildGrassTexture(img) {
  const c = document.createElement("canvas");
  c.width = 16; c.height = 48;
  const g = c.getContext("2d");
  g.imageSmoothingEnabled = false;
  // source is square (554x554); grass occupies the top ~50%, dirt the bottom.
  g.drawImage(img, 0, 0, 554, 200, 0, 0, 16, 16);        // top face (green)
  g.drawImage(img, 0, 0, 554, 430, 0, 16, 16, 16);       // side (grass over dirt)
  g.drawImage(img, 0, 470, 554, 84, 0, 32, 16, 16);      // bottom (dirt)
  g.fillStyle = "rgba(0,0,0,0.25)";
  g.fillRect(0, 15, 16, 1);
  g.fillRect(0, 31, 16, 1);
  const tex = new THREE.CanvasTexture(c);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.flipY = true;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function loadGrassImage() {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => res(img);
    img.onerror = () => rej(new Error("grass image failed to load"));
    img.src = "uploads/images__4_-2.jpg";
  });
}

// per-type instanced meshes
const materials = {};
const instances = {};
async function initMaterials() {
  let grassImg = null;
  try { grassImg = await loadGrassImage(); } catch (e) { grassImg = null; }
  for (const b of BLOCKS) {
    const map = (b.id === 0 && grassImg)
      ? buildGrassTexture(grassImg)
      : rowTexture(b.colors, b.id * 77 + 13);
    const mat = new THREE.MeshLambertMaterial({
      map,
      transparent: !!b.transparent,
      opacity: b.transparent ? 0.75 : 1,
    });
    materials[b.id] = mat;
  }
}

// box geometry sized for instance y-offset
const boxGeo = new THREE.BoxGeometry(1, 1, 1);
boxGeo.translate(0, 0.5, 0);

// ---------------- Terrain generation ----------------
function generate(wSize, seedOffset) {
  const noise = makeNoise(seedOffset || 1234);
  const n2 = makeNoise((seedOffset || 1234) + 9999);
  const rnd = mulberry32(seedOffset || 1234);
  for (let x = -wSize; x < wSize; x++) {
    for (let z = -wSize; z < wSize; z++) {
      const h = Math.floor(
        6 +
        noise(x * 0.06, z * 0.06) * 5 +
        n2(x * 0.02, z * 0.02) * 3
      );
      const water = false; // keep it land-focused
      let genY = Math.max(1, Math.min(14, h));
      for (let y = 0; y <= genY; y++) {
        let id;
        if (y === genY) id = GRASS_ID;
        else if (y >= genY - 2) id = DIRT_ID;
        else id = STONE_ID;
        world.set(key(x, y, z), id);
      }
    }
  }
}

// ---------------- Instancing ----------------
function rebuildType(id) {
  const group = instances[id];
  if (!group) return;
  group.count = 0;
  const mat = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const pos = new THREE.Vector3();
  const sc = new THREE.Vector3(1, 1, 1);
  let i = 0;
  for (const [k, v] of world) {
    if (v !== id) continue;
    const p = k.split(",");
    pos.set(+p[0] + 0.5, +p[1], +p[2] + 0.5);
    mat.compose(pos, q, sc);
    group.setMatrixAt(i++, mat);
  }
  group.count = i;
  group.instanceMatrix.needsUpdate = true;
}

function createInstanced(type, cap) {
  const mesh = new THREE.InstancedMesh(boxGeo, materials[type], cap);
  mesh.count = 0;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  scene.add(mesh);
  return mesh;
}

function buildInstances() {
  // generous caps; will grow if exceeded via reserve
  for (const b of BLOCKS) {
    instances[b.id] = createInstanced(b.id, 200000);
  }
  rebuildAll();
}

function rebuildAll() {
  for (const b of BLOCKS) {
    rebuildType(b.id, true);
  }
  refreshHighlight();
}

// ---------------- Player ----------------
const WORLD_MIN = -46;
const WORLD_MAX = 46;
const REACH = 7;

const player = {
  pos: new THREE.Vector3(0.5, 30, 0.5),
  yaw: 0,
  pitch: 0,
  vel: new THREE.Vector3(),
  grounded: false,
  flying: false,
};

// ---------------- Input ----------------
const keys = {};
let lastSpaceTap = 0;
addEventListener("keydown", (e) => {
  keys[e.code] = true;
  if (e.code === "Space" && !e.repeat && locked) {
    const now = performance.now();
    if (now - lastSpaceTap < 300) player.flying = !player.flying;
    lastSpaceTap = now;
  }
});
addEventListener("keyup", (e) => { keys[e.code] = false; });

let locked = false;
const menu = document.getElementById("menu");
const startBtn = document.getElementById("start");

function groundHeight(x, z) {
  const ix = Math.floor(x), iz = Math.floor(z);
  for (let y = 30; y >= 0; y--) {
    if (world.has(key(ix, y, iz))) return y + 1;
  }
  return 0;
}

// ---------------- Voxel raycast (DDA) ----------------
function raycastVoxel(origin, dir, maxDist) {
  let x = Math.floor(origin.x);
  let y = Math.floor(origin.y);
  let z = Math.floor(origin.z);
  const stepX = dir.x > 0 ? 1 : -1;
  const stepY = dir.y > 0 ? 1 : -1;
  const stepZ = dir.z > 0 ? 1 : -1;
  const tDeltaX = Math.abs(1 / (dir.x || 1e-9));
  const tDeltaY = Math.abs(1 / (dir.y || 1e-9));
  const tDeltaZ = Math.abs(1 / (dir.z || 1e-9));
  let tMaxX = ((dir.x > 0 ? x + 1 - origin.x : origin.x - x) / (dir.x || 1e-9));
  let tMaxY = ((dir.y > 0 ? y + 1 - origin.y : origin.y - y) / (dir.y || 1e-9));
  let tMaxZ = ((dir.z > 0 ? z + 1 - origin.z : origin.z - z) / (dir.z || 1e-9));
  const norm = Math.sqrt(dir.x * dir.x + dir.y * dir.y + dir.z * dir.z) || 1;

  let t = 0;
  let normal = new THREE.Vector3(0, 0, 0);
  for (let i = 0; i < 256; i++) {
    if (world.has(key(x, y, z))) {
      return { hit: true, x, y, z, normal: normal.clone(), dist: t };
    }
    if (t > maxDist) return { hit: false };
    if (tMaxX < tMaxY && tMaxX < tMaxZ) { x += stepX; t = tMaxX; tMaxX += tDeltaX; normal.set(-stepX, 0, 0); }
    else if (tMaxY < tMaxZ) { y += stepY; t = tMaxY; tMaxY += tDeltaY; normal.set(0, -stepY, 0); }
    else { z += stepZ; t = tMaxZ; tMaxZ += tDeltaZ; normal.set(0, 0, -stepZ); }
    t; norm;
  }
  return { hit: false };
}

// highlight box on targeted block
const highlightMat = new THREE.MeshBasicMaterial({
  color: 0x000000,
  wireframe: true,
  transparent: true,
  opacity: 0.25,
});
const highlight = new THREE.Mesh(new THREE.BoxGeometry(1.002, 1.002, 1.002), highlightMat);
scene.add(highlight);
highlight.visible = false;

function refreshHighlight() {
  const dir = getForward();
  const hit = raycastVoxel(camera.position, dir, REACH);
  if (hit.hit) {
    highlight.visible = true;
    highlight.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
    window._hit = hit;
  } else {
    highlight.visible = false;
    window._hit = null;
  }
}

// ---------------- Particles (block break) ----------------
let particleGeo = new THREE.BoxGeometry(0.5, 0.5, 0.5);
let particleMat;

function spawnBreakParticles(blockId, px, py, pz) {
  const rnd = multimedia(blockId * 31);
  const color = new THREE.Color(BLOCKS[blockId].colors.side[0]).multiplyScalar(1.4);
  for (let i = 0; i < 10; i++) {
    const p = new THREE.Mesh(particleGeo, new THREE.MeshBasicMaterial({ color: color }));
    p.position.set(px + (rnd() - 0.5) * 0.6, py + (rnd() - 0.5) * 0.6, pz + (rnd() - 0.5) * 0.6);
    p.vel = new THREE.Vector3(
      (rnd() - 0.5) * 2, rnd() * 2 + 1, (rnd() - 0.5) * 2
    );
    p.life = 0;
    p.maxLife = 0.5 + rnd() * 0.4;
    scene.add(p);
    particles.push(p);
  }
}

function multimedia(s) { return mulberry32(s); }

function updateParticles(dt) {
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.life += dt;
    p.vel.y -= 12 * dt;
    p.position.addScaledVector(p.vel, dt);
    if (p.life >= p.maxLife) {
      scene.remove(p);
      p.geometry.dispose();
      p.material.dispose();
      particles.splice(i, 1);
    }
  }
}

// ---------------- Editing ----------------
function inReach(p) {
  return camera.position.distanceTo(p) <= REACH + 1;
}

function breakBlock(hit) {
  const k = key(hit.x, hit.y, hit.z);
  const id = world.get(k);
  if (id === undefined) return;
  world.delete(k);
  edits[k] = null;
  saveEdits();
  spawnBreakParticles(id, hit.x, hit.y, hit.z);
  rebuildType(id);
  refreshHighlight();
}

function placeBlock(nx, ny, nz) {
  if (nx < WORLD_MIN || nx > WORLD_MAX || ny < 0 || ny > 30 || nz < WORLD_MIN || nz > WORLD_MAX) return;
  if (world.has(key(nx, ny, nz))) return;
  const playerCell = key(Math.floor(player.pos.x), Math.floor(player.pos.y), Math.floor(player.pos.z));
  if (key(nx, ny, nz) === playerCell) return;
  const id = currentBlock();
  const k = key(nx, ny, nz);
  world.set(k, id);
  edits[k] = id;
  saveEdits();
  rebuildType(id);
  refreshHighlight();
}

// ---------------- Hotbar ----------------
function currentBlock() { return selected; }
let selected = 0;
const hotbar = document.getElementById("hotbar");

function buildHotbar() {
  hotbar.innerHTML = "";
  BLOCKS.forEach((b, i) => {
    const slot = document.createElement("div");
    slot.className = "slot" + (i === selected ? " active" : "");
    const sw = document.createElement("div");
    sw.className = "swatch";
    sw.style.background = `rgb(${(b.colors.top[0] >> 16) & 255},${(b.colors.top[0] >> 8) & 255},${b.colors.top[0] & 255})`;
    const keyLab = document.createElement("span");
    keyLab.className = "key";
    keyLab.textContent = i + 1;
    slot.appendChild(sw);
    slot.appendChild(keyLab);
    slot.onclick = () => selectBlock(i);
    hotbar.appendChild(slot);
  });
}

function selectBlock(i) {
  selected = i;
  buildHotbar();
}

addEventListener("keydown", (e) => {
  if (/^Digit[1-9]$/.test(e.code)) {
    selectBlock(Number(e.code.slice(5)) - 1);
  }
});

// ---------------- Mouse ----------------
let mouseDown = null;
addEventListener("mousedown", (e) => {
  if (!locked) return;
  mouseDown = e.button;
  refreshHighlight();
  doAction();
});
addEventListener("mouseup", (e) => {
  if (e.button === mouseDown) mouseDown = null;
});

// hold to break continuously
setInterval(() => {
  if (locked && mouseDown === 0 && window._hit) {
    breakBlock(window._hit);
  }
}, 90);

function doAction() {
  const hit = window._hit;
  if (!hit || !hit.hit) return;
  if (mouseDown === 0) {
    breakBlock(hit);
  } else if (mouseDown === 2) {
    const nx = hit.x + hit.normal.x;
    const ny = hit.y + hit.normal.y;
    const nz = hit.z + hit.normal.z;
    placeBlock(nx, ny, nz);
  }
}
addEventListener("contextmenu", (e) => e.preventDefault());

// ---------------- Controls ----------------
const dirVec = new THREE.Vector3();
function getForward() {
  // Derive forward straight from the camera so walking and aiming match.
  camera.getWorldDirection(dirVec);
  return dirVec;
}

document.addEventListener("pointerlockchange", () => {
  locked = document.pointerLockElement === renderer.domElement;
  const active = document.getElementById("blockmap");
  if (active) active.hidden = locked;
  menu.style.display = locked ? "none" : "flex";
});

startBtn.addEventListener("click", () => {
  renderer.domElement.requestPointerLock();
});

renderer.domElement.addEventListener("mousemove", (e) => {
  if (!locked) return;
  const sens = 0.0022;
  player.yaw -= e.movementX * sens;
  player.pitch -= e.movementY * sens;
  player.pitch = Math.max(-1.55, Math.min(1.55, player.pitch));
});

// ---------------- Camera update ----------------
function updateCamera() {
  camera.position.set(player.pos.x, player.pos.y + 1.6, player.pos.z);
  camera.rotation.order = "YXZ";
  camera.rotation.y = player.yaw;
  camera.rotation.x = player.pitch;
}

// ---------------- Game loop ----------------
let last = performance.now();

function collisionMove() {
  const f = getForward();
  const right = new THREE.Vector3().copy(f).cross(new THREE.Vector3(0, 1, 0));
  const move = new THREE.Vector3();
  if (keys["KeyW"]) move.add(f);
  if (keys["KeyS"]) move.sub(f);
  if (keys["KeyD"]) move.add(right);
  if (keys["KeyA"]) move.sub(right);

  // ----- Flying (creative mode): no gravity, move in any direction -----
  if (player.flying) {
    if (keys["Space"]) move.y += 1;
    if (keys["ShiftLeft"] || keys["ShiftRight"]) move.y -= 1;
    const speed = 12 * (keys.ctrlKey ? 0.5 : 1) * (keys["Space"] ? 1 : 1);
    if (move.lengthSq() > 0) move.normalize().multiplyScalar(speed);
    player.pos.addScaledVector(move, dt);
    player.vel.set(0, 0, 0);
    player.grounded = false;
    // slow hover decay so it stays smooth
    if ((keys["ShiftLeft"] || keys["ShiftRight"]) && !keys["Space"]) {
      player.pos.y -= 4 * dt;
    }
    player.pos.x = Math.max(WORLD_MIN, Math.min(WORLD_MAX, player.pos.x));
    player.pos.z = Math.max(WORLD_MIN, Math.min(WORLD_MAX, player.pos.z));
    if (player.pos.y < 1) player.pos.y = 1;
    if (player.pos.y > 60) player.pos.y = 60;
    return;
  }

  // horizontal
  const speed = 5.5 * (keys["ShiftLeft"] || keys["ShiftRight"] ? 2.1 : 1) * (keys.ctrlKey ? 0.5 : 1);
  if (move.lengthSq() > 0) move.normalize();
  move.multiplyScalar(speed);

  const nx = player.pos.x + move.x * dt;
  const nz = player.pos.z + move.z * dt;
  const gh = groundHeight(nx, nz);
  if (player.pos.y >= gh - 0.001) {
    player.pos.x = nx;
    player.pos.z = nz;
  }

  // vertical physics + collision
  player.vel.y -= 25 * dt;
  const feetY = player.pos.y;

  // moving up
  if (player.vel.y > 0) {
    const topY = player.pos.y + 1.8;
    const ny = player.pos.y + player.vel.y * dt;
    const bY = Math.floor(ny + 1.8 + 0.001);
    const topCell = key(Math.floor(player.pos.x), bY, Math.floor(player.pos.z));
    if (world.has(topCell)) {
      player.vel.y = 0;
      player.pos.y = bY - 1.8 - 0.001;
    } else {
      player.pos.y = ny;
    }
  } else {
    // falling
    if (world.has(key(Math.floor(player.pos.x), Math.floor(feetY - 0.001), Math.floor(player.pos.z)))) {
      player.vel.y = 0;
      player.pos.y = Math.floor(feetY - 0.001) + 1;
      player.grounded = true;
    } else {
      const gh = groundHeight(player.pos.x, player.pos.z);
      let desired = player.pos.y + player.vel.y * dt;
      if (desired <= gh) {
        player.pos.y = gh;
        player.vel.y = 0;
        player.grounded = true;
      } else {
        player.pos.y = desired;
        player.grounded = false;
      }
    }
  }

  // jump
  if ((keys["Space"] ) && player.grounded) {
    player.vel.y = 8.5;
    player.grounded = false;
  }

  // clamp to world
  player.pos.x = Math.max(WORLD_MIN, Math.min(WORLD_MAX, player.pos.x));
  player.pos.z = Math.max(WORLD_MIN, Math.min(WORLD_MAX, player.pos.z));
  if (player.pos.y < -20) { player.pos.y = groundHeight(player.pos.x, player.pos.z); player.vel.y = 0; }
}

// ---------------- Init ----------------
initMaterials().then(() => {
  generate(46, 1337);
  loadEdits();
  applyEdits();
  buildInstances();
  buildHotbar();
  spawn();
  menu.style.display = "flex";
  loadCloudEdits().then(() => {
    applyEdits();
    rebuildAll();
  });
});

const reticle = document.getElementById("crosshair");
const flyTag = document.getElementById("flytag");

function animate() {
  requestAnimationFrame(animate);
  const now = performance.now();
  dt = Math.min(0.05, (now - last) / 1000);
  last = now;

  if (locked) {
    collisionMove();
    updateCamera();
    refreshHighlight();
    updateParticles(dt);
    flyTag.hidden = !player.flying;
  }

  renderer.render(scene, camera);
}

let dt = 0.016;
// drop the player at spawn (world must exist first; called from init chain)
function spawn() {
  const gh = groundHeight(player.pos.x, player.pos.z);
  player.pos.y = gh;
  updateCamera();
}
animate();

addEventListener("resize", () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});